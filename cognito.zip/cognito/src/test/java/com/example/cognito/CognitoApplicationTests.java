package com.example.cognito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CognitoApplicationTests {

    @Test
    void contextLoads() {
    }

}
